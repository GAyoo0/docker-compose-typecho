<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
    </body>
</html>
<?php
/** 注册一个结束插件 */
Typecho_Plugin::factory('admin/footer.php')->end();
